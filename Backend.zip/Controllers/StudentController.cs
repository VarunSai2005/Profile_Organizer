using Backend.Data;
using Backend.Models;
using Microsoft.AspNetCore.Mvc;

namespace Backend.Controllers;

[ApiController]
[Route("api1/[controller]")]

public class StudentController : ControllerBase
{
    private readonly ApplicationDbContext stcxt;
    public StudentController ( ApplicationDbContext stcxt)
    {
        this.stcxt = stcxt;
    }

    [HttpPost("add")]
    public IActionResult addStudent(Student student)
    {
        if (student == null || student.Name == null || student.Email == null || student.Mobile == null)
            return BadRequest();
        var st = stcxt.Find<Student>(student.RollNumber);
        if (st != null)
            return BadRequest();
        stcxt.Add(student);
        stcxt.SaveChanges();
        return Created("", student);
    }


    [HttpGet]
    public IActionResult getAllStudents()
    {
        return Ok();
    }
    

}